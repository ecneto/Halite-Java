import java.util.ArrayList;

/**
 * Created by enet on 11/11/16.
 */
public interface MovesStrategy {
    ArrayList<Move> getMoves();
}
