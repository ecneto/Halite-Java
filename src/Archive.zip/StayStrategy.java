/**
 * Created by enet on 11/13/16.
 */
public interface StayStrategy {
    Boolean[][] getStayDecisions();
}
