/**
 * Created by enet on 11/11/16.
 */
public interface MoveStrategy {
    Move getMove();
}
